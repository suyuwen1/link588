<?php
$dbhost="localhost";
$dbuser="root";
$dbpassword="root";
$dbname="dedecms";
$dbdk="3306";
?>